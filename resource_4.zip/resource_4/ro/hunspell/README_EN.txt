Romanian Spelling Dictionary
Authors:
    Lucian Constantin (http://rospell.sourceforge.net)
    Sorin Sbarnea (http://www.i18n.ro)
    Alexandru Szasz (Mozilla and OpenOffice.org Romanian Translation Team)
    Ionuț Păduraru (http://www.archeus.ro)
    Adrian Stoica (OpenOffice.org Romanian Translation Team) <adrian dot stoica at cuvinte dot ro>
    Nicu Buculei (OpenOffice.org Romanian Translation Team) <nicu at apsro dot com>
    Cătălin Frâncu (http://dexonline.ro)
    Ionel Mugurel Ciobică (previous aspell releases) <tgakic at sg10 chem tue nl>
    Mihai Budiu (ispell dictionary) <mihaib at cs cmu edu>
License:  GPL 2.0/LGPL 2.1/MPL 1.1 tri-license, please see COPYING.GPL,
   COPYING.LGPL, and COPYING.MPL for more details

Support:
   Please direct all your questions to http://groups.google.com/group/rospell mailing list.
