﻿This Slovenian spelling dictionary was created by (in alphabetical order)/
Slovenski slovar za črkovanje so ustvarili (v abecednem redu):
   Amebis, d.o.o.
   Tomaž Erjavec
   Aleš Košir
   Primož Peterlin

The Slovenian spelling dictionary is covered by the GNU/LGPL and GNU/GPL
License and supports Slovenian language (sl_SI).
Slovenski slovar za črkovanje je izdan pod licencama GNU/LGPL in GNU/GPL
ter podpira slovenski jezik (sl_SI).

The affix file adapted by/Datoteko pripon priredil:
Robert Ludvik, <r@aufbix.org>

The OpenOffice.org extension by/Razširitev OpenOffice.org pripravil:
Martin Srebotnjak, <miles@filmsi.net>

Project was supported in part by Ministry of Information Society (MID,
Republic of Slovenia) and Linux User Group of Slovenia (Lugos).
Projekt sta delno podprla Ministrstvo za informacijsko družbo (MID,
Republika Slovenija) in društvo LUGOS.

Bug report/O napakah poročajte: <ales.kosir@pingo.org>

=======================================================================
http://external.openoffice.org/ form data:

Product Name: Slovenian spellcheck dictionary
Product Version: 1.0
Vendor or Owner Name: Amebis, d.o.o., Tomaž Erjavec, Aleš Košir, Primož Peterlin
Vendor or Owner Contact: ales.kosir@pingo.org
OpenOffice.org Contact: bobe@openoffice.org
Date of First Use / date of License: NA/October 2006
URL for Product Information: http://nl.ijs.si/GNUsl/
URL for License: http://www.gnu.org/copyleft/lgpl.html
Purpose: Slovenian spellcheck dictionary
Type of Encryption: none
Binary or Source Code: Source
=======================================================================

For the avoidance of doubt, except that if any license choice other
than GPL or LGPL is available it will apply instead, Sun elects to use
only the Lesser General Public License version 2.1 (LGPLv2) at this
time for any software where a choice of LGPL license versions is made
available with the language indicating that LGPLv2.1 or any later
version may be used, or where a choice of which version of the LGPL is
applied is otherwise unspecified.
