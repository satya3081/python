Kontrola pravopisu
------------------

Toto je slovenský slovník pre kontrolu pravopisu vyvíjaný a udržiavaný 
v projekte sk-spell (http://sk-spell.sk.cx/)

Tieto dáta sú vydané pod týmito licenciami:
  * The GNU General Public License (GPL) Version 2, June 1991
  * GNU Lesser General Public License Version 2.1, February 1999
  * Mozilla Public License 1.1 (MPL 1.1)

Ďalšie informácie nájde na týchto stránkach:
	http://sk-spell.sk.cx/ispell-sk
	http://sk-spell.sk.cx/myspell-sk
	http://sk-spell.sk.cx/aspell-sk
	http://sk-spell.sk.cx/hunspell-sk
