This Russian dictionary is partially converted to morfologik-speller format by Yakov Reztsov in 2012 from
http://www.aot.ru  (http://sourceforge.net/projects/seman/)
License: LGPL.
Source dictionary:
http://sourceforge.net/p/seman/svn/HEAD/tree/trunk/Dicts/SrcMorph/RusSrc/  file morphs.mrd  Revision 99
Corrections:  Yakov Reztsov
Added frequency information for spell-checking dictionary in 2014 by Yakov Reztsov from http://www.aot.ru  (http://sourceforge.net/projects/seman/)
Source frequency information http://sourceforge.net/p/seman/svn/HEAD/tree/trunk/Dicts/SrcBinDict/  file   WordData.txt
It was converted to use with spell-checking dictionary in 2014 by Yakov Reztsov. 